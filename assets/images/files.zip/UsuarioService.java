package com.empresa.app.service;

import com.empresa.app.model.Usuario;
import com.empresa.app.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

// @Service: aquí va TODA la lógica de negocio (las reglas de la app)
// El Controller NO debe tener esta lógica, solo llamar al Service
@Service
public class UsuarioService {

    // Spring inyecta automáticamente el Repository que necesitamos
    @Autowired
    private UsuarioRepository usuarioRepository;

    // Crear un usuario nuevo
    public Usuario crearUsuario(Usuario usuario) {
        return usuarioRepository.guardar(usuario);
    }

    // Listar todos los usuarios
    public List<Usuario> listarUsuarios() {
        return usuarioRepository.obtenerTodos();
    }

    // Buscar usuario por ID — devuelve null si no existe
    public Optional<Usuario> buscarPorId(Long id) {
        return usuarioRepository.buscarPorId(id);
    }
}
