package com.empresa.app.controller;

import com.empresa.app.model.Usuario;
import com.empresa.app.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

// @RestController: esta clase recibe las peticiones HTTP (desde el navegador o Postman)
// @RequestMapping: todas las rutas empiezan con /api/usuarios
@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {

    // Usamos el Service — NUNCA tocamos el Repository directamente aquí
    @Autowired
    private UsuarioService usuarioService;

    // POST /api/usuarios  → Crear usuario
    // El @RequestBody convierte el JSON que llega a un objeto Usuario
    @PostMapping
    public ResponseEntity<Usuario> crearUsuario(@RequestBody Usuario usuario) {
        Usuario nuevo = usuarioService.crearUsuario(usuario);
        return ResponseEntity.ok(nuevo);
    }

    // GET /api/usuarios  → Listar todos
    @GetMapping
    public ResponseEntity<List<Usuario>> listarUsuarios() {
        List<Usuario> lista = usuarioService.listarUsuarios();
        return ResponseEntity.ok(lista);
    }

    // GET /api/usuarios/{id}  → Buscar por ID
    // El {id} en la URL se captura con @PathVariable
    @GetMapping("/{id}")
    public ResponseEntity<Usuario> buscarPorId(@PathVariable Long id) {
        return usuarioService.buscarPorId(id)
                .map(ResponseEntity::ok)                        // si existe, devuelve 200 OK
                .orElse(ResponseEntity.notFound().build());     // si no, devuelve 404
    }
}
