package com.empresa.app.repository;

import com.empresa.app.model.Usuario;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

// @Repository: le dice a Spring que esta clase guarda y recupera datos
@Repository
public class UsuarioRepository {

    // Simulamos una "base de datos" con una lista en memoria
    private List<Usuario> baseDeDatos = new ArrayList<>();
    private Long contadorId = 1L; // para generar IDs automáticos

    // Guardar un usuario nuevo
    public Usuario guardar(Usuario usuario) {
        usuario.setId(contadorId++); // asignamos ID automático
        baseDeDatos.add(usuario);
        return usuario;
    }

    // Obtener todos los usuarios
    public List<Usuario> obtenerTodos() {
        return baseDeDatos;
    }

    // Buscar usuario por su ID
    public Optional<Usuario> buscarPorId(Long id) {
        return baseDeDatos.stream()
                .filter(u -> u.getId().equals(id))
                .findFirst();
    }
}
